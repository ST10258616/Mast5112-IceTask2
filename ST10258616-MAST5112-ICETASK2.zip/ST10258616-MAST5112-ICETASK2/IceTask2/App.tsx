import React, { useState} from 'react';
import { View, Text, FlatList, TouchableOpacity, ScrollView, Image, StyleSheet, Button} from 'react-native'

const recipesData = [
  {
    id: '1',
    title: 'Pasta Carbonara',
    image: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.allrecipes.com%2Frecipe%2F11973%2Fspaghetti-carbonara-ii%2F&psig=AOvVaw0sTUXhMkRYHW1y4nJK7Lg9&ust=1693901479194000&source=images&cd=vfe&opi=89978449&ved=0CA4QjRxqFwoTCKC1___AkIEDFQAAAAAdAAAAABAD',
    ingredients: ['Spaghetti, eggs, chicken, parmesan cheese, black pepper'],
    instructions: '1. Boil spaghetti 2. Mix eggs, parmesan cheese and black pepper. 3. Cook chicken. 4. Mixe everything together.',
  },

  {
    id: '2',
    title: 'Chicken stir-Fry',
    image: 'https://www.google.com/imgres?imgurl=https%3A%2F%2Fnatashaskitchen.com%2Fwp-content%2Fuploads%2F2018%2F08%2FChicken-Stir-Fry-1-1.jpg&tbnid=bX9y9yAyRYZ7PM&vet=12ahUKEwjJotv2x5GBAxVXxgIHHdLHBywQMygAegQIARBx..i&imgrefurl=https%3A%2F%2Fnatashaskitchen.com%2Fchicken-stir-fry-recipe%2F&docid=oh7OGNGGB3G78M&w=1200&h=1800&q=chicken%20stir%20fry&ved=2ahUKEwjJotv2x5GBAxVXxgIHHdLHBywQMygAegQIARBx',
    ingredients: ['chicken breast, salt, pepper, broccoli, mushroom, oil, sauce'],
    instructions: '',
  },

  {
    id: '3',
    title: 'Margherita Pizza',
    image: 'https://www.google.com/imgres?imgurl=https%3A%2F%2Fuk.ooni.com%2Fcdn%2Fshop%2Farticles%2F20220211142645-margherita-9920.jpg%3Fcrop%3Dcenter%26height%3D800%26v%3D1660843558%26width%3D800&tbnid=A6rvFlXyzPB0vM&vet=12ahUKEwiMpZTdyJGBAxUYNuwKHRsLAb8QMygBegQIARB0..i&imgrefurl=https%3A%2F%2Fuk.ooni.com%2Fblogs%2Frecipes%2Fmargherita-pizza&docid=uTEBLKhJ1uvHvM&w=800&h=800&q=margherita%20pizza&ved=2ahUKEwiMpZTdyJGBAxUYNuwKHRsLAb8QMygBegQIARB0',
    ingredients: [''],
    instructions: '',
  },

  {
    id: '4',
    title: 'Choclate Chip Cookies',
    image: 'https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.modernhoney.com%2Fwp-content%2Fuploads%2F2019%2F12%2FOne-Bowl-Chocolate-Chip-Cookie-Recipe-5-scaled.jpg&tbnid=nxks12G20VwCJM&vet=12ahUKEwiR74OOyZGBAxUH3KQKHWuvC0UQMygEegQIARB9..i&imgrefurl=https%3A%2F%2Fwww.modernhoney.com%2Fone-bowl-chocolate-chip-cookie-recipe%2F&docid=qaSW7lQvhAPuZM&w=2245&h=2560&q=chocolate%20chip%20cookies&ved=2ahUKEwiR74OOyZGBAxUH3KQKHWuvC0UQMygEegQIARB9',
    ingredients: [''],
    instructions: '',
  },

];

const App = () => {
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  const renderRecipeItem = ({item}) => (
    <TouchableOpacity onPress={() => setSelectedRecipe(item)} style={styles.recipeItem}>
      <Image source={{ uri: item.image }} style={styles.recipeImage}/>
      <Text style={styles.recipeTitle}>{item.title}</Text>
    </TouchableOpacity>
  );
  const renderRecipeDetails = () => {
    if (!selectedRecipe) return null;

    return (
      <ScrollView style={styles.recipeDetails}>
        <Image
        source={{ uri: selectedRecipe.image}}
style={styles.recipeImageDetail}
/>
<Text style={styles.recipeTitle}>{selectedRecipe.title}</Text>
<Text style={styles.recipeSubtitle}>Ingredients:</Text>
<Text>{selectedRecipe.ingredients.join('/n')}</Text>
<Text style={styles.recipeSubtitle}>Instructions:</Text>
<Text>{selectedRecipe.instructions}</Text>

<View style={styles.closeButtonContainer}>
  <Button
  title="Close"
  onPress={() => setSelectedRecipe(null)}
  />
</View>
      </ScrollView>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.appTitle}>Recipe App</Text>
      <FlatList
      data={recipesData}
      renderItem={renderRecipeItem}
      keyExtractor={(item) => item.id}
      />
      {renderRecipeDetails()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  appTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  recipeItem: {
    marginBottom: 16,
    alignItems: 'center',
  },
  recipeImage: {
    width: 200,
    height: 200,
    borderRadius: 8,
  },
  recipeTitle: {
    fontSize: 18,
    marginTop: 8,
  },
  recipeDetails: {
    display: 'none',
  },
  recipeImageDetail: {
    width: 300,
    height: 300,
    borderRadius: 8,
    alignSelf: 'center',
  },
  recipeSubtitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 8,
  },
  closeButtonContainer: {
    marginTop: 16,
    alignItems: 'center',
  },
});

export default App;
